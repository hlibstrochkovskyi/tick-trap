# tick-trap matched high-order certification cost

Fixed-state/control h and psi evaluation plus evidence assembly; excludes search, selection and offline reference costs

| Strategy | Width tolerance | Bernstein split budget | Queries | Accepted | Rejected | Unknown | Reference-safe excluded | Reference-safe unresolved | Total splits | Median per-control time (µs) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| sacbf_relaxed | None | None | 259 | 48 | 211 | 0 | 97 | 0 | 0 | 141.6 |
| sturm | None | None | 259 | 146 | 113 | 0 | 0 | 0 | 0 | 1214.0 |
| minimum | 1/1000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 242.7 |
| sign | 1/1000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 244.7 |
| auxiliary_sign | 1/1000000 | 0 | 259 | 131 | 43 | 85 | 0 | 14 | 0 | 176.7 |
| minimum | 1/1000000 | 8 | 259 | 135 | 92 | 32 | 0 | 10 | 1369 | 475.2 |
| sign | 1/1000000 | 8 | 259 | 144 | 111 | 4 | 0 | 1 | 218 | 258.2 |
| auxiliary_sign | 1/1000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 124 | 183.1 |
| minimum | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 2830 | 737.5 |
| sign | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 223 | 256.4 |
| auxiliary_sign | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 127 | 183.5 |
| minimum | 1/1000000000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 243.5 |
| sign | 1/1000000000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 246.0 |
| auxiliary_sign | 1/1000000000000 | 0 | 259 | 131 | 43 | 85 | 0 | 14 | 0 | 177.2 |
| minimum | 1/1000000000000 | 8 | 259 | 135 | 92 | 32 | 0 | 10 | 1402 | 477.2 |
| sign | 1/1000000000000 | 8 | 259 | 144 | 111 | 4 | 0 | 1 | 218 | 259.6 |
| auxiliary_sign | 1/1000000000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 124 | 182.9 |
| minimum | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 5712 | 1322.0 |
| sign | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 250 | 264.6 |
| auxiliary_sign | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 144 | 183.2 |

| Width tolerance | Budget | Dual sign decision | Auxiliary-only decision | Controls |
| --- | ---: | --- | --- | ---: |
| 1/1000000 | 0 | accepted | accepted | 130 |
| 1/1000000 | 0 | rejected | rejected | 43 |
| 1/1000000 | 0 | rejected | unknown | 16 |
| 1/1000000 | 0 | unknown | accepted | 1 |
| 1/1000000 | 0 | unknown | unknown | 69 |
| 1/1000000 | 8 | accepted | accepted | 144 |
| 1/1000000 | 8 | rejected | rejected | 111 |
| 1/1000000 | 8 | unknown | rejected | 1 |
| 1/1000000 | 8 | unknown | unknown | 3 |
| 1/1000000 | 64 | accepted | accepted | 144 |
| 1/1000000 | 64 | rejected | rejected | 112 |
| 1/1000000 | 64 | unknown | unknown | 3 |
| 1/1000000000000 | 0 | accepted | accepted | 130 |
| 1/1000000000000 | 0 | rejected | rejected | 43 |
| 1/1000000000000 | 0 | rejected | unknown | 16 |
| 1/1000000000000 | 0 | unknown | accepted | 1 |
| 1/1000000000000 | 0 | unknown | unknown | 69 |
| 1/1000000000000 | 8 | accepted | accepted | 144 |
| 1/1000000000000 | 8 | rejected | rejected | 111 |
| 1/1000000000000 | 8 | unknown | rejected | 1 |
| 1/1000000000000 | 8 | unknown | unknown | 3 |
| 1/1000000000000 | 64 | accepted | accepted | 145 |
| 1/1000000000000 | 64 | rejected | rejected | 113 |
| 1/1000000000000 | 64 | unknown | unknown | 1 |

| Strategy | Tolerance | Budget | Independently safe accepted | Unsafe h or psi rejected | Safe excluded | Safe unknown | Unsafe unknown |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| sacbf_relaxed | None | None | 48 | 113 | 98 | 0 | 0 |
| sturm | None | None | 146 | 113 | 0 | 0 | 0 |
| minimum | 1/1000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| sign | 1/1000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| auxiliary_sign | 1/1000000 | 0 | 131 | 43 | 0 | 15 | 70 |
| minimum | 1/1000000 | 8 | 135 | 92 | 0 | 11 | 21 |
| sign | 1/1000000 | 8 | 144 | 111 | 0 | 2 | 2 |
| auxiliary_sign | 1/1000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| sign | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| auxiliary_sign | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| sign | 1/1000000000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| auxiliary_sign | 1/1000000000000 | 0 | 131 | 43 | 0 | 15 | 70 |
| minimum | 1/1000000000000 | 8 | 135 | 92 | 0 | 11 | 21 |
| sign | 1/1000000000000 | 8 | 144 | 111 | 0 | 2 | 2 |
| auxiliary_sign | 1/1000000000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |
| sign | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |
| auxiliary_sign | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |

| Baseline / candidate | Tolerance | Budget | Paired time ratio p10 | Median | p90 |
| --- | --- | ---: | ---: | ---: | ---: |
| sacbf_relaxed / minimum | 1/1000000 | 0 | 0.547 | 0.581 | 0.632 |
| sacbf_relaxed / sign | 1/1000000 | 0 | 0.547 | 0.579 | 0.635 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 0 | 0.752 | 0.798 | 0.872 |
| sacbf_relaxed / sturm | 1/1000000 | 0 | 0.108 | 0.118 | 0.131 |
| minimum / sign | 1/1000000 | 0 | 0.957 | 0.996 | 1.041 |
| minimum / auxiliary_sign | 1/1000000 | 0 | 1.299 | 1.371 | 1.441 |
| minimum / sturm | 1/1000000 | 0 | 0.186 | 0.203 | 0.226 |
| sign / auxiliary_sign | 1/1000000 | 0 | 1.312 | 1.377 | 1.431 |
| sign / sturm | 1/1000000 | 0 | 0.185 | 0.203 | 0.226 |
| auxiliary_sign / sturm | 1/1000000 | 0 | 0.135 | 0.147 | 0.165 |
| sacbf_relaxed / minimum | 1/1000000 | 8 | 0.205 | 0.232 | 0.581 |
| sacbf_relaxed / sign | 1/1000000 | 8 | 0.369 | 0.560 | 0.617 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 8 | 0.571 | 0.769 | 0.845 |
| sacbf_relaxed / sturm | 1/1000000 | 8 | 0.108 | 0.118 | 0.131 |
| minimum / sign | 1/1000000 | 8 | 0.992 | 1.821 | 2.777 |
| minimum / auxiliary_sign | 1/1000000 | 8 | 1.346 | 2.661 | 3.832 |
| minimum / sturm | 1/1000000 | 8 | 0.208 | 0.516 | 0.571 |
| sign / auxiliary_sign | 1/1000000 | 8 | 1.283 | 1.376 | 1.546 |
| sign / sturm | 1/1000000 | 8 | 0.190 | 0.220 | 0.331 |
| auxiliary_sign / sturm | 1/1000000 | 8 | 0.136 | 0.160 | 0.215 |
| sacbf_relaxed / minimum | 1/1000000 | 64 | 0.101 | 0.195 | 0.575 |
| sacbf_relaxed / sign | 1/1000000 | 64 | 0.368 | 0.560 | 0.618 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 64 | 0.573 | 0.765 | 0.857 |
| sacbf_relaxed / sturm | 1/1000000 | 64 | 0.108 | 0.118 | 0.131 |
| minimum / sign | 1/1000000 | 64 | 0.989 | 2.850 | 4.478 |
| minimum / auxiliary_sign | 1/1000000 | 64 | 1.345 | 4.220 | 6.346 |
| minimum / sturm | 1/1000000 | 64 | 0.209 | 0.606 | 1.140 |
| sign / auxiliary_sign | 1/1000000 | 64 | 1.280 | 1.384 | 1.567 |
| sign / sturm | 1/1000000 | 64 | 0.189 | 0.219 | 0.332 |
| auxiliary_sign / sturm | 1/1000000 | 64 | 0.136 | 0.160 | 0.225 |
| sacbf_relaxed / minimum | 1/1000000000000 | 0 | 0.548 | 0.579 | 0.635 |
| sacbf_relaxed / sign | 1/1000000000000 | 0 | 0.546 | 0.575 | 0.623 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 0 | 0.750 | 0.792 | 0.873 |
| sacbf_relaxed / sturm | 1/1000000000000 | 0 | 0.108 | 0.118 | 0.131 |
| minimum / sign | 1/1000000000000 | 0 | 0.950 | 0.995 | 1.038 |
| minimum / auxiliary_sign | 1/1000000000000 | 0 | 1.293 | 1.372 | 1.428 |
| minimum / sturm | 1/1000000000000 | 0 | 0.184 | 0.202 | 0.227 |
| sign / auxiliary_sign | 1/1000000000000 | 0 | 1.300 | 1.370 | 1.441 |
| sign / sturm | 1/1000000000000 | 0 | 0.186 | 0.203 | 0.230 |
| auxiliary_sign / sturm | 1/1000000000000 | 0 | 0.135 | 0.148 | 0.167 |
| sacbf_relaxed / minimum | 1/1000000000000 | 8 | 0.202 | 0.226 | 0.574 |
| sacbf_relaxed / sign | 1/1000000000000 | 8 | 0.361 | 0.558 | 0.622 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 8 | 0.569 | 0.765 | 0.855 |
| sacbf_relaxed / sturm | 1/1000000000000 | 8 | 0.108 | 0.118 | 0.131 |
| minimum / sign | 1/1000000000000 | 8 | 0.992 | 1.831 | 2.796 |
| minimum / auxiliary_sign | 1/1000000000000 | 8 | 1.353 | 2.712 | 3.854 |
| minimum / sturm | 1/1000000000000 | 8 | 0.207 | 0.519 | 0.566 |
| sign / auxiliary_sign | 1/1000000000000 | 8 | 1.277 | 1.381 | 1.554 |
| sign / sturm | 1/1000000000000 | 8 | 0.188 | 0.221 | 0.341 |
| auxiliary_sign / sturm | 1/1000000000000 | 8 | 0.138 | 0.160 | 0.217 |
| sacbf_relaxed / minimum | 1/1000000000000 | 64 | 0.056 | 0.110 | 0.579 |
| sacbf_relaxed / sign | 1/1000000000000 | 64 | 0.362 | 0.556 | 0.614 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 64 | 0.560 | 0.763 | 0.844 |
| sacbf_relaxed / sturm | 1/1000000000000 | 64 | 0.108 | 0.118 | 0.131 |
| minimum / sign | 1/1000000000000 | 64 | 0.995 | 5.091 | 8.904 |
| minimum / auxiliary_sign | 1/1000000000000 | 64 | 1.352 | 7.316 | 12.674 |
| minimum / sturm | 1/1000000000000 | 64 | 0.208 | 1.060 | 2.137 |
| sign / auxiliary_sign | 1/1000000000000 | 64 | 1.277 | 1.382 | 1.565 |
| sign / sturm | 1/1000000000000 | 64 | 0.190 | 0.221 | 0.332 |
| auxiliary_sign / sturm | 1/1000000000000 | 64 | 0.137 | 0.161 | 0.216 |

All strategies target continuous h and psi safety at the same declared controls.
auxiliary_sign certifies psi and derives h by linear comparison; it reports no numerical geometric minimum.
SACBF rejection is a failed sufficient condition; Bernstein rejection has a negative witness; Sturm rejection has an exact algebraic sign proof.
Initial-domain exclusions are not counted as rejections. Unknown reference signs remain unknown.
Minimum and sign queries use identical tolerances/budgets; sign stopping need not attain the minimum width.
Subdivision budget scope: per_control. Native SACBF has no subdivisions; its repeated measurements are reused across tolerance/budget comparisons.
Optional sturm reruns exact algebra inside the timed region; it is not a cache lookup or an online controller.
Sturm has no subdivision allowance or hard runtime bound; zero splits do not mean zero cost or equal work. Its one measured group is reused across numerical settings.
Independent exact algebraic signs distinguish safe/unsafe h-and-psi paths; unsafe psi alone does not mean collision.
Online unknowns remain unknown even if the independent offline reference resolves their signs.
Paired ratios divide the baseline per-control median by the candidate median; full repeat distributions and query order are saved.
These are descriptive distributions on this finite set, not confidence intervals or hard deadline bounds.
5 seeded, interleaved repeats per setting and control.
[Exact evidence, reference audit and all timings](study.json).
