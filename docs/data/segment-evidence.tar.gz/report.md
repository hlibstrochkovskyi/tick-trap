# Chord and held-trajectory contracts

Offline elementary chord-deviation contract on fixed exact holds; no controller changes, viability claim, timings, MPC reproduction or novel algorithm

| Fixed hold | Sampled endpoints | Connecting chord | Tube sufficient condition | Actual trajectory sign reference |
| --- | --- | --- | --- | --- |
| stationary_outside | safe | safe | safe | safe |
| linear_tangent | safe | safe | safe | safe |
| linear_positive | safe | safe | safe | safe |
| linear_negative | safe | unsafe | unknown | unsafe |
| linear_collision | safe | unsafe | unknown | unsafe |
| safe_chord_curved_collision | safe | safe | unknown | unsafe |
| unsafe_chord_safe_arch | safe | unsafe | unknown | safe |
| tangent_chord_safe_arch | safe | safe | unknown | safe |
| inflated_chord_tangent | safe | safe | safe | safe |
| inflated_chord_positive | safe | safe | safe | safe |
| inflated_chord_negative | safe | safe | unknown | unsafe |
| missing_cross_term_trap | safe | safe | unknown | unsafe |
| negative_sign_before_squaring | unsafe | unsafe | unknown | unsafe |
| nonsquare_acceleration_norm | safe | safe | safe | safe |
| one_unresolved_obstacle | safe | safe | unknown | safe |

Failed tube implications remain unknown, even when the separate offline sign reference resolves them.
This is elementary exact interpolation geometry, not a published SSCBF/MPC implementation or a new controller.
No execution, recursive feasibility, runtime ranking or hardware guarantee is inferred.
