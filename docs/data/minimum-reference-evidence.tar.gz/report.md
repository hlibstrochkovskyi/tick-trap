# Independent minimum-reference audit

Deterministic offline independent minimum-enclosure cross-check on exact archived planar h and psi polynomials. Complete signs, minimum widths, split counts and execution decisions remain separate; no timing or equal primitive-work claim

| Tolerance | Bisection allowance | Unique polynomials | Stationary width reached | Bernstein width reached | Stationary unknown signs | Bernstein unknown signs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 1/1000000 | 0 | 550 | 351 | 353 | 96 | 88 |
| 1/1000000 | 8 | 550 | 354 | 389 | 7 | 4 |
| 1/1000000 | 64 | 550 | 550 | 550 | 3 | 4 |
| 1/1000000000000 | 0 | 550 | 351 | 352 | 96 | 88 |
| 1/1000000000000 | 8 | 550 | 354 | 354 | 7 | 4 |
| 1/1000000000000 | 64 | 550 | 550 | 550 | 2 | 2 |

All matched and archived enclosure intersections are nonempty.
Width attainment does not decide a sign across zero; a complete sign reference remains separate.
A root-box bisection and a Bernstein split do not represent equal primitive work. No timing samples were collected.
No controller, online unknown or fallback is changed.
