# Matched geometric predicate costs

Offline fixed-control geometric h>=0 comparison on an inherited cohort; psi preservation and diagnostic endpoint/chord checks remain separate. Includes evidence construction, excludes cohort/reference work; no controller, SSCBF reproduction, equal primitive-work, hard deadline or novelty claim

| Predicate | Tolerance | Shared splits | Geometrically safe accepted | Unsafe rejected | Safe unknown | Unsafe unknown | Accepted auxiliary-unsafe | Median us/control |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| command_tube | None | None | 148 | 0 | 36 | 75 | 20 | 94.949 |
| box_tube | None | None | 122 | 0 | 62 | 75 | 11 | 93.526 |
| sturm | None | None | 184 | 75 | 0 | 0 | 38 | 498.268 |
| minimum | 1/1000000 | 0 | 159 | 42 | 25 | 33 | 18 | 115.407 |
| sign | 1/1000000 | 0 | 159 | 42 | 25 | 33 | 18 | 115.077 |
| minimum | 1/1000000 | 8 | 183 | 75 | 1 | 0 | 37 | 386.528 |
| sign | 1/1000000 | 8 | 183 | 75 | 1 | 0 | 37 | 144.953 |
| minimum | 1/1000000 | 64 | 183 | 75 | 1 | 0 | 37 | 418.859 |
| sign | 1/1000000 | 64 | 183 | 75 | 1 | 0 | 37 | 145.784 |
| minimum | 1/1000000000000 | 0 | 159 | 42 | 25 | 33 | 18 | 114.045 |
| sign | 1/1000000000000 | 0 | 159 | 42 | 25 | 33 | 18 | 115.227 |
| minimum | 1/1000000000000 | 8 | 183 | 75 | 1 | 0 | 37 | 388.922 |
| sign | 1/1000000000000 | 8 | 183 | 75 | 1 | 0 | 37 | 145.705 |
| minimum | 1/1000000000000 | 64 | 183 | 75 | 1 | 0 | 37 | 813.642 |
| sign | 1/1000000000000 | 64 | 183 | 75 | 1 | 0 | 37 | 146.365 |

These predicates require geometry only. Accepting an auxiliary-unsafe path is not an h-and-psi certificate.
Endpoint/chord diagnostics are reported separately and do not certify the physical path.
Tube failures remain unknown. Zero splits for algebra or tubes do not mean zero cost or an equal-work comparison.
Timing is empirical, interleaved and descriptive; offline references, action search and execution are excluded.
