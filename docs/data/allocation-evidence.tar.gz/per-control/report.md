# Certification work allocation audit

Offline assigned-budget replay and counterfactual allocation diagnosis; no recorded decision is changed. Uses the existing Bernstein engine, with independent algebraic sign cross-checks. Input timing samples and historical audit predicates are outside verification scope.

| Strategy | Tolerance | Budget | Accepted | Rejected | Unknown | Allocation-limited unknown controls | Unknown at full per-polynomial limits | Splits beyond sign decisions |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| sacbf_relaxed | None | None | 48 | 211 | 0 | 0 | 0 | 0 |
| minimum | 1/1000000 | 0 | 130 | 59 | 70 | 0 | 70 | 0 |
| sign | 1/1000000 | 0 | 130 | 59 | 70 | 0 | 70 | 0 |
| auxiliary_sign | 1/1000000 | 0 | 131 | 43 | 85 | 0 | 85 | 0 |
| minimum | 1/1000000 | 8 | 135 | 92 | 32 | 29 | 3 | 1245 |
| sign | 1/1000000 | 8 | 144 | 111 | 4 | 1 | 3 | 0 |
| auxiliary_sign | 1/1000000 | 8 | 144 | 112 | 3 | 0 | 3 | 0 |
| minimum | 1/1000000 | 64 | 144 | 112 | 3 | 0 | 3 | 2607 |
| sign | 1/1000000 | 64 | 144 | 112 | 3 | 0 | 3 | 0 |
| auxiliary_sign | 1/1000000 | 64 | 144 | 112 | 3 | 0 | 3 | 0 |
| minimum | 1/1000000000000 | 0 | 130 | 59 | 70 | 0 | 70 | 0 |
| sign | 1/1000000000000 | 0 | 130 | 59 | 70 | 0 | 70 | 0 |
| auxiliary_sign | 1/1000000000000 | 0 | 131 | 43 | 85 | 0 | 85 | 0 |
| minimum | 1/1000000000000 | 8 | 135 | 92 | 32 | 29 | 3 | 1278 |
| sign | 1/1000000000000 | 8 | 144 | 111 | 4 | 1 | 3 | 0 |
| auxiliary_sign | 1/1000000000000 | 8 | 144 | 112 | 3 | 0 | 3 | 0 |
| minimum | 1/1000000000000 | 64 | 145 | 113 | 1 | 0 | 1 | 5462 |
| sign | 1/1000000000000 | 64 | 145 | 113 | 1 | 0 | 1 | 0 |
| auxiliary_sign | 1/1000000000000 | 64 | 145 | 113 | 1 | 0 | 1 | 0 |

Full per-polynomial allowances can spend more total work than the shared budget. They are an offline counterfactual.
Refinement after a sign decision can still be needed for the minimum-enclosure width request.
Unknown at the full allowance means unresolved at these limits, not mathematically undecidable.
These traces do not change controller decisions, certify a fallback, or bound elapsed computation time.
[Exact query traces](audit.json) · [Input hashes and replay source](metadata.json)
