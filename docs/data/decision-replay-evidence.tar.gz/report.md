# Planar decision replay evidence

Deterministic scientific-record replay and declared cohort coverage. Physical certificates, complete decisions and task flags are checked; reused implementation, excluded clocks/display estimates and model validity retain their documented limits.

| Cohort | Method | Runs | Decisions | Executed holds | Failed decisions | Candidate assessments |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| archived | auxiliary_sign_candidates | 8 | 600 | 600 | 0 | 943 |
| archived | high_order_sign_candidates | 8 | 600 | 600 | 0 | 943 |
| archived | sacbf_relaxed_candidates | 8 | 600 | 600 | 0 | 1267 |
| generated | auxiliary_sign_candidates | 2 | 3 | 3 | 0 | 3 |
| generated | backup_candidates | 3 | 8 | 7 | 1 | 1 |
| generated | endpoint_candidates | 3 | 3 | 2 | 1 | 27 |
| generated | high_order_sign_candidates | 1 | 1 | 1 | 0 | 1 |
| generated | high_order_trajectory_candidates | 1 | 1 | 1 | 0 | 1 |
| generated | hocbf | 3 | 3 | 1 | 2 | 0 |
| generated | nominal | 3 | 2 | 2 | 0 | 0 |
| generated | sacbf_candidates | 2 | 2 | 2 | 0 | 7 |
| generated | sacbf_relaxed_candidates | 1 | 1 | 1 | 0 | 1 |
| generated | segment_candidates | 1 | 1 | 1 | 0 | 1 |
| generated | trajectory_candidates | 3 | 3 | 1 | 2 | 26 |
| generated | zocbf_candidates | 1 | 1 | 1 | 0 | 1 |

Verified means faithful to the current implementation, not necessarily safe.
An unsafe but accurately recorded endpoint-controller example is intentionally retained.
A valid online comparison survives an offline oracle unknown; genuinely uncertified execution stops.
Clocks and floating estimates are explicitly excluded and are not authenticated by this replay.
