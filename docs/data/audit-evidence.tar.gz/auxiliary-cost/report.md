# tick-trap matched high-order certification cost

Fixed-state/control h and psi evaluation plus evidence assembly; excludes search, selection and offline reference costs

| Strategy | Width tolerance | Splits per polynomial | Queries | Accepted | Rejected | Unknown | Reference-safe excluded | Reference-safe unresolved | Total splits | Median per-control time (µs) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| sacbf_relaxed | None | None | 259 | 48 | 211 | 0 | 97 | 0 | 0 | 102.7 |
| minimum | 1/1000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 159.7 |
| sign | 1/1000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 160.9 |
| auxiliary_sign | 1/1000000 | 0 | 259 | 131 | 43 | 85 | 0 | 14 | 0 | 115.0 |
| minimum | 1/1000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 2281 | 488.1 |
| sign | 1/1000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 219 | 240.8 |
| auxiliary_sign | 1/1000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 124 | 160.6 |
| minimum | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 2830 | 509.0 |
| sign | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 223 | 240.0 |
| auxiliary_sign | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 127 | 159.8 |
| minimum | 1/1000000000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 158.9 |
| sign | 1/1000000000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 158.6 |
| auxiliary_sign | 1/1000000000000 | 0 | 259 | 131 | 43 | 85 | 0 | 14 | 0 | 115.1 |
| minimum | 1/1000000000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 2330 | 522.5 |
| sign | 1/1000000000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 219 | 242.2 |
| auxiliary_sign | 1/1000000000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 124 | 157.1 |
| minimum | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 5715 | 901.3 |
| sign | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 250 | 240.5 |
| auxiliary_sign | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 144 | 156.6 |

| Width tolerance | Budget | Dual sign decision | Auxiliary-only decision | Controls |
| --- | ---: | --- | --- | ---: |
| 1/1000000 | 0 | accepted | accepted | 130 |
| 1/1000000 | 0 | rejected | rejected | 43 |
| 1/1000000 | 0 | rejected | unknown | 16 |
| 1/1000000 | 0 | unknown | accepted | 1 |
| 1/1000000 | 0 | unknown | unknown | 69 |
| 1/1000000 | 8 | accepted | accepted | 144 |
| 1/1000000 | 8 | rejected | rejected | 112 |
| 1/1000000 | 8 | unknown | unknown | 3 |
| 1/1000000 | 64 | accepted | accepted | 144 |
| 1/1000000 | 64 | rejected | rejected | 112 |
| 1/1000000 | 64 | unknown | unknown | 3 |
| 1/1000000000000 | 0 | accepted | accepted | 130 |
| 1/1000000000000 | 0 | rejected | rejected | 43 |
| 1/1000000000000 | 0 | rejected | unknown | 16 |
| 1/1000000000000 | 0 | unknown | accepted | 1 |
| 1/1000000000000 | 0 | unknown | unknown | 69 |
| 1/1000000000000 | 8 | accepted | accepted | 144 |
| 1/1000000000000 | 8 | rejected | rejected | 112 |
| 1/1000000000000 | 8 | unknown | unknown | 3 |
| 1/1000000000000 | 64 | accepted | accepted | 145 |
| 1/1000000000000 | 64 | rejected | rejected | 113 |
| 1/1000000000000 | 64 | unknown | unknown | 1 |

| Strategy | Tolerance | Budget | Independently safe accepted | Unsafe h or psi rejected | Safe excluded | Safe unknown | Unsafe unknown |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| sacbf_relaxed | None | None | 48 | 113 | 98 | 0 | 0 |
| minimum | 1/1000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| sign | 1/1000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| auxiliary_sign | 1/1000000 | 0 | 131 | 43 | 0 | 15 | 70 |
| minimum | 1/1000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| sign | 1/1000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| auxiliary_sign | 1/1000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| sign | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| auxiliary_sign | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| sign | 1/1000000000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| auxiliary_sign | 1/1000000000000 | 0 | 131 | 43 | 0 | 15 | 70 |
| minimum | 1/1000000000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| sign | 1/1000000000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| auxiliary_sign | 1/1000000000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |
| sign | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |
| auxiliary_sign | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |

| Baseline / candidate | Tolerance | Budget | Paired time ratio p10 | Median | p90 |
| --- | --- | ---: | ---: | ---: | ---: |
| sacbf_relaxed / minimum | 1/1000000 | 0 | 0.553 | 0.600 | 0.692 |
| sacbf_relaxed / sign | 1/1000000 | 0 | 0.549 | 0.594 | 0.684 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 0 | 0.755 | 0.830 | 0.930 |
| minimum / sign | 1/1000000 | 0 | 0.942 | 0.997 | 1.037 |
| minimum / auxiliary_sign | 1/1000000 | 0 | 1.271 | 1.367 | 1.438 |
| sign / auxiliary_sign | 1/1000000 | 0 | 1.295 | 1.377 | 1.461 |
| sacbf_relaxed / minimum | 1/1000000 | 8 | 0.131 | 0.227 | 0.585 |
| sacbf_relaxed / sign | 1/1000000 | 8 | 0.382 | 0.570 | 0.655 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 8 | 0.591 | 0.778 | 0.902 |
| minimum / sign | 1/1000000 | 8 | 0.990 | 2.487 | 4.212 |
| minimum / auxiliary_sign | 1/1000000 | 8 | 1.340 | 3.651 | 5.595 |
| sign / auxiliary_sign | 1/1000000 | 8 | 1.282 | 1.379 | 1.562 |
| sacbf_relaxed / minimum | 1/1000000 | 64 | 0.107 | 0.198 | 0.584 |
| sacbf_relaxed / sign | 1/1000000 | 64 | 0.381 | 0.562 | 0.657 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 64 | 0.587 | 0.780 | 0.883 |
| minimum / sign | 1/1000000 | 64 | 0.980 | 2.752 | 4.502 |
| minimum / auxiliary_sign | 1/1000000 | 64 | 1.355 | 4.051 | 6.352 |
| sign / auxiliary_sign | 1/1000000 | 64 | 1.244 | 1.383 | 1.577 |
| sacbf_relaxed / minimum | 1/1000000000000 | 0 | 0.550 | 0.599 | 0.685 |
| sacbf_relaxed / sign | 1/1000000000000 | 0 | 0.550 | 0.598 | 0.692 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 0 | 0.758 | 0.824 | 0.935 |
| minimum / sign | 1/1000000000000 | 0 | 0.959 | 1.001 | 1.069 |
| minimum / auxiliary_sign | 1/1000000000000 | 0 | 1.290 | 1.373 | 1.463 |
| sign / auxiliary_sign | 1/1000000000000 | 0 | 1.270 | 1.376 | 1.441 |
| sacbf_relaxed / minimum | 1/1000000000000 | 8 | 0.133 | 0.217 | 0.587 |
| sacbf_relaxed / sign | 1/1000000000000 | 8 | 0.380 | 0.563 | 0.665 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 8 | 0.596 | 0.776 | 0.900 |
| minimum / sign | 1/1000000000000 | 8 | 0.987 | 2.625 | 4.235 |
| minimum / auxiliary_sign | 1/1000000000000 | 8 | 1.342 | 3.728 | 5.668 |
| sign / auxiliary_sign | 1/1000000000000 | 8 | 1.245 | 1.382 | 1.581 |
| sacbf_relaxed / minimum | 1/1000000000000 | 64 | 0.058 | 0.113 | 0.588 |
| sacbf_relaxed / sign | 1/1000000000000 | 64 | 0.377 | 0.566 | 0.653 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 64 | 0.589 | 0.776 | 0.893 |
| minimum / sign | 1/1000000000000 | 64 | 0.985 | 5.141 | 9.331 |
| minimum / auxiliary_sign | 1/1000000000000 | 64 | 1.333 | 7.312 | 12.393 |
| sign / auxiliary_sign | 1/1000000000000 | 64 | 1.262 | 1.378 | 1.568 |

All strategies target continuous h and psi safety at the same declared controls.
auxiliary_sign certifies psi and derives h by linear comparison; it reports no numerical geometric minimum.
SACBF rejection is a failed sufficient condition; polynomial rejection has a negative witness.
Initial-domain exclusions are not counted as rejections. Unknown reference signs remain unknown.
Minimum and sign queries use identical tolerances/budgets; sign stopping need not attain the minimum width.
Subdivision budget scope: per_polynomial. Native SACBF has no subdivisions; its repeated measurements are reused across tolerance/budget comparisons.
Independent exact algebraic signs distinguish safe/unsafe h-and-psi paths; unsafe psi alone does not mean collision.
Online unknowns remain unknown even if the independent offline reference resolves their signs.
Paired ratios divide the baseline per-control median by the candidate median; full repeat distributions and query order are saved.
These are descriptive distributions on this finite set, not confidence intervals or hard deadline bounds.
5 seeded, interleaved repeats per setting and control.
[Exact evidence, reference audit and all timings](study.json).
