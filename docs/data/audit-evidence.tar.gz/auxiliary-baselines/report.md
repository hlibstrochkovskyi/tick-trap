# tick-trap planar experiment

Safety, initial-set membership, sufficient viability and task progress are separate results.
Stopping a simulation at a failed decision is not an emergency braking maneuver.

| Method | Runs | Safe full horizon | Collision | QP infeasible | Search exhausted | Budget stops | Uncertified | Other stops |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| auxiliary_sign_candidates | 8 | 8 | 0 | 0 | 0 | 0 | 0 | 0 |
| high_order_sign_candidates | 8 | 8 | 0 | 0 | 0 | 0 | 0 | 0 |
| sacbf_relaxed_candidates | 8 | 8 | 0 | 0 | 0 | 0 | 0 | 0 |

| Run / trajectory | Method | Period (s) | Candidate budget | Initial p | Initial viability | Outcome | At goal at end | Stored steps |
| --- | --- | ---: | --- | --- | --- | --- | --- | ---: |
| [0](trajectories/run-000.svg) | sacbf_relaxed_candidates | 0.05 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [1](trajectories/run-001.svg) | sacbf_relaxed_candidates | 0.05 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [2](trajectories/run-002.svg) | sacbf_relaxed_candidates | 0.1 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [3](trajectories/run-003.svg) | sacbf_relaxed_candidates | 0.1 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [4](trajectories/run-004.svg) | sacbf_relaxed_candidates | 0.2 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [5](trajectories/run-005.svg) | sacbf_relaxed_candidates | 0.2 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [6](trajectories/run-006.svg) | sacbf_relaxed_candidates | 0.4 | None | ['-2', '3/10'] | certified | horizon | False | 0 |
| [7](trajectories/run-007.svg) | sacbf_relaxed_candidates | 0.4 | None | ['-2', '7/10'] | certified | horizon | False | 0 |
| [8](trajectories/run-008.svg) | high_order_sign_candidates | 0.05 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [9](trajectories/run-009.svg) | high_order_sign_candidates | 0.05 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [10](trajectories/run-010.svg) | high_order_sign_candidates | 0.1 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [11](trajectories/run-011.svg) | high_order_sign_candidates | 0.1 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [12](trajectories/run-012.svg) | high_order_sign_candidates | 0.2 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [13](trajectories/run-013.svg) | high_order_sign_candidates | 0.2 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [14](trajectories/run-014.svg) | high_order_sign_candidates | 0.4 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [15](trajectories/run-015.svg) | high_order_sign_candidates | 0.4 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [16](trajectories/run-016.svg) | auxiliary_sign_candidates | 0.05 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [17](trajectories/run-017.svg) | auxiliary_sign_candidates | 0.05 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [18](trajectories/run-018.svg) | auxiliary_sign_candidates | 0.1 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [19](trajectories/run-019.svg) | auxiliary_sign_candidates | 0.1 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [20](trajectories/run-020.svg) | auxiliary_sign_candidates | 0.2 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [21](trajectories/run-021.svg) | auxiliary_sign_candidates | 0.2 | None | ['-2', '7/10'] | certified | horizon | True | 0 |
| [22](trajectories/run-022.svg) | auxiliary_sign_candidates | 0.4 | None | ['-2', '3/10'] | certified | horizon | True | 0 |
| [23](trajectories/run-023.svg) | auxiliary_sign_candidates | 0.4 | None | ['-2', '7/10'] | certified | horizon | True | 0 |

`certified` initial viability means a particular admissible stopping plan was certified safe.
A safe completed horizon can use a validated online comparison proof while the separate offline geometric oracle remains unknown.
`oracle_confirmed_horizon` requires every offline geometric check to be safe; `observed_continuous_status` always retains its raw answer.
An unknown offline result without a recognized valid online proof stops execution. Negative witnesses always stop; contradictory proofs raise an error.
`unknown` does not mean nonviable. The complete planar viability kernel is not computed.
Finite candidate exhaustion does not prove continuous-input infeasibility.
Endpoint and segment checks certify different properties from continuous-path checks.
Controller timings include any online trajectory certificates; the offline oracle is measured separately.
`offline_proof_replay_ns` audits the existing controller evidence and is separate from solve time and deadline checks.
The stateless methods use stopping-plan checks as offline diagnostics only.
backup_candidates performs its replacement checks online and reports reuse of the stored certified plan explicitly.
Controller initialization cost is recorded separately before simulated execution.
Operation budgets and empirical deadline measurements do not establish hard real-time safety.

- [Full exact records](runs.json)
- [Per-run metrics](summary.csv)
- [Configuration and source provenance](metadata.json)
