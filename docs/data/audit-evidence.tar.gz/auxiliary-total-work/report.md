# tick-trap matched high-order certification cost

Fixed-state/control h and psi evaluation plus evidence assembly; excludes search, selection and offline reference costs

| Strategy | Width tolerance | Splits per polynomial | Queries | Accepted | Rejected | Unknown | Reference-safe excluded | Reference-safe unresolved | Total splits | Median per-control time (µs) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| sacbf_relaxed | None | None | 259 | 48 | 211 | 0 | 97 | 0 | 0 | 95.1 |
| minimum | 1/1000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 154.7 |
| sign | 1/1000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 155.3 |
| auxiliary_sign | 1/1000000 | 0 | 259 | 131 | 43 | 85 | 0 | 14 | 0 | 112.3 |
| minimum | 1/1000000 | 8 | 259 | 135 | 92 | 32 | 0 | 10 | 1369 | 393.5 |
| sign | 1/1000000 | 8 | 259 | 144 | 111 | 4 | 0 | 1 | 218 | 214.7 |
| auxiliary_sign | 1/1000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 124 | 150.0 |
| minimum | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 2830 | 504.5 |
| sign | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 223 | 214.0 |
| auxiliary_sign | 1/1000000 | 64 | 259 | 144 | 112 | 3 | 0 | 1 | 127 | 150.1 |
| minimum | 1/1000000000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 154.7 |
| sign | 1/1000000000000 | 0 | 259 | 130 | 59 | 70 | 0 | 15 | 0 | 155.0 |
| auxiliary_sign | 1/1000000000000 | 0 | 259 | 131 | 43 | 85 | 0 | 14 | 0 | 112.3 |
| minimum | 1/1000000000000 | 8 | 259 | 135 | 92 | 32 | 0 | 10 | 1402 | 393.8 |
| sign | 1/1000000000000 | 8 | 259 | 144 | 111 | 4 | 0 | 1 | 218 | 215.5 |
| auxiliary_sign | 1/1000000000000 | 8 | 259 | 144 | 112 | 3 | 0 | 1 | 124 | 148.4 |
| minimum | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 5712 | 836.4 |
| sign | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 250 | 214.0 |
| auxiliary_sign | 1/1000000000000 | 64 | 259 | 145 | 113 | 1 | 0 | 0 | 144 | 148.9 |

| Width tolerance | Budget | Dual sign decision | Auxiliary-only decision | Controls |
| --- | ---: | --- | --- | ---: |
| 1/1000000 | 0 | accepted | accepted | 130 |
| 1/1000000 | 0 | rejected | rejected | 43 |
| 1/1000000 | 0 | rejected | unknown | 16 |
| 1/1000000 | 0 | unknown | accepted | 1 |
| 1/1000000 | 0 | unknown | unknown | 69 |
| 1/1000000 | 8 | accepted | accepted | 144 |
| 1/1000000 | 8 | rejected | rejected | 111 |
| 1/1000000 | 8 | unknown | rejected | 1 |
| 1/1000000 | 8 | unknown | unknown | 3 |
| 1/1000000 | 64 | accepted | accepted | 144 |
| 1/1000000 | 64 | rejected | rejected | 112 |
| 1/1000000 | 64 | unknown | unknown | 3 |
| 1/1000000000000 | 0 | accepted | accepted | 130 |
| 1/1000000000000 | 0 | rejected | rejected | 43 |
| 1/1000000000000 | 0 | rejected | unknown | 16 |
| 1/1000000000000 | 0 | unknown | accepted | 1 |
| 1/1000000000000 | 0 | unknown | unknown | 69 |
| 1/1000000000000 | 8 | accepted | accepted | 144 |
| 1/1000000000000 | 8 | rejected | rejected | 111 |
| 1/1000000000000 | 8 | unknown | rejected | 1 |
| 1/1000000000000 | 8 | unknown | unknown | 3 |
| 1/1000000000000 | 64 | accepted | accepted | 145 |
| 1/1000000000000 | 64 | rejected | rejected | 113 |
| 1/1000000000000 | 64 | unknown | unknown | 1 |

| Strategy | Tolerance | Budget | Independently safe accepted | Unsafe h or psi rejected | Safe excluded | Safe unknown | Unsafe unknown |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| sacbf_relaxed | None | None | 48 | 113 | 98 | 0 | 0 |
| minimum | 1/1000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| sign | 1/1000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| auxiliary_sign | 1/1000000 | 0 | 131 | 43 | 0 | 15 | 70 |
| minimum | 1/1000000 | 8 | 135 | 92 | 0 | 11 | 21 |
| sign | 1/1000000 | 8 | 144 | 111 | 0 | 2 | 2 |
| auxiliary_sign | 1/1000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| sign | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| auxiliary_sign | 1/1000000 | 64 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| sign | 1/1000000000000 | 0 | 130 | 59 | 0 | 16 | 54 |
| auxiliary_sign | 1/1000000000000 | 0 | 131 | 43 | 0 | 15 | 70 |
| minimum | 1/1000000000000 | 8 | 135 | 92 | 0 | 11 | 21 |
| sign | 1/1000000000000 | 8 | 144 | 111 | 0 | 2 | 2 |
| auxiliary_sign | 1/1000000000000 | 8 | 144 | 112 | 0 | 2 | 1 |
| minimum | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |
| sign | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |
| auxiliary_sign | 1/1000000000000 | 64 | 145 | 113 | 0 | 1 | 0 |

| Baseline / candidate | Tolerance | Budget | Paired time ratio p10 | Median | p90 |
| --- | --- | ---: | ---: | ---: | ---: |
| sacbf_relaxed / minimum | 1/1000000 | 0 | 0.554 | 0.596 | 0.684 |
| sacbf_relaxed / sign | 1/1000000 | 0 | 0.545 | 0.592 | 0.689 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 0 | 0.755 | 0.817 | 0.921 |
| minimum / sign | 1/1000000 | 0 | 0.941 | 0.998 | 1.049 |
| minimum / auxiliary_sign | 1/1000000 | 0 | 1.274 | 1.368 | 1.444 |
| sign / auxiliary_sign | 1/1000000 | 0 | 1.284 | 1.375 | 1.461 |
| sacbf_relaxed / minimum | 1/1000000 | 8 | 0.209 | 0.247 | 0.590 |
| sacbf_relaxed / sign | 1/1000000 | 8 | 0.374 | 0.561 | 0.660 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 8 | 0.579 | 0.772 | 0.909 |
| minimum / sign | 1/1000000 | 8 | 0.982 | 1.817 | 2.795 |
| minimum / auxiliary_sign | 1/1000000 | 8 | 1.341 | 2.663 | 3.856 |
| sign / auxiliary_sign | 1/1000000 | 8 | 1.267 | 1.387 | 1.567 |
| sacbf_relaxed / minimum | 1/1000000 | 64 | 0.104 | 0.199 | 0.588 |
| sacbf_relaxed / sign | 1/1000000 | 64 | 0.377 | 0.562 | 0.656 |
| sacbf_relaxed / auxiliary_sign | 1/1000000 | 64 | 0.567 | 0.776 | 0.907 |
| minimum / sign | 1/1000000 | 64 | 0.990 | 2.753 | 4.538 |
| minimum / auxiliary_sign | 1/1000000 | 64 | 1.342 | 4.216 | 6.463 |
| sign / auxiliary_sign | 1/1000000 | 64 | 1.264 | 1.382 | 1.553 |
| sacbf_relaxed / minimum | 1/1000000000000 | 0 | 0.551 | 0.592 | 0.690 |
| sacbf_relaxed / sign | 1/1000000000000 | 0 | 0.549 | 0.594 | 0.685 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 0 | 0.751 | 0.819 | 0.921 |
| minimum / sign | 1/1000000000000 | 0 | 0.956 | 1.000 | 1.039 |
| minimum / auxiliary_sign | 1/1000000000000 | 0 | 1.283 | 1.373 | 1.442 |
| sign / auxiliary_sign | 1/1000000000000 | 0 | 1.280 | 1.376 | 1.443 |
| sacbf_relaxed / minimum | 1/1000000000000 | 8 | 0.211 | 0.239 | 0.589 |
| sacbf_relaxed / sign | 1/1000000000000 | 8 | 0.364 | 0.560 | 0.666 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 8 | 0.579 | 0.769 | 0.897 |
| minimum / sign | 1/1000000000000 | 8 | 0.982 | 1.826 | 2.789 |
| minimum / auxiliary_sign | 1/1000000000000 | 8 | 1.330 | 2.695 | 3.886 |
| sign / auxiliary_sign | 1/1000000000000 | 8 | 1.255 | 1.385 | 1.563 |
| sacbf_relaxed / minimum | 1/1000000000000 | 64 | 0.057 | 0.113 | 0.589 |
| sacbf_relaxed / sign | 1/1000000000000 | 64 | 0.374 | 0.558 | 0.655 |
| sacbf_relaxed / auxiliary_sign | 1/1000000000000 | 64 | 0.583 | 0.772 | 0.913 |
| minimum / sign | 1/1000000000000 | 64 | 0.979 | 5.195 | 9.003 |
| minimum / auxiliary_sign | 1/1000000000000 | 64 | 1.330 | 7.378 | 12.580 |
| sign / auxiliary_sign | 1/1000000000000 | 64 | 1.264 | 1.382 | 1.583 |

All strategies target continuous h and psi safety at the same declared controls.
auxiliary_sign certifies psi and derives h by linear comparison; it reports no numerical geometric minimum.
SACBF rejection is a failed sufficient condition; polynomial rejection has a negative witness.
Initial-domain exclusions are not counted as rejections. Unknown reference signs remain unknown.
Minimum and sign queries use identical tolerances/budgets; sign stopping need not attain the minimum width.
Subdivision budget scope: per_control. Native SACBF has no subdivisions; its repeated measurements are reused across tolerance/budget comparisons.
Independent exact algebraic signs distinguish safe/unsafe h-and-psi paths; unsafe psi alone does not mean collision.
Online unknowns remain unknown even if the independent offline reference resolves their signs.
Paired ratios divide the baseline per-control median by the candidate median; full repeat distributions and query order are saved.
These are descriptive distributions on this finite set, not confidence intervals or hard deadline bounds.
5 seeded, interleaved repeats per setting and control.
[Exact evidence, reference audit and all timings](study.json).
