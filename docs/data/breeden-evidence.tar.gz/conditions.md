# Published sampled-data wall conditions

Restricted wall specializations of Breeden 2103.03677v1 Theorems 1–3; exact model, observations and held actuation. Fixed and gamma/T-matched gains are separate. Geometric safety, barrier preservation and viability are distinct; no global feasibility or full paper reproduction claim.

| Gain policy | Period | Method | Applicable controls | Safe accepted | Unsafe b/geometry accepted | Safe excluded | Full b-safe horizons | Infeasible stops | Outside-domain stops |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fixed | 1/50 | continuous_cbf | 147 | 80 | 0 | 47 | 6 / 8 | 1 | 1 |
| fixed | 1/50 | breeden | 147 | 68 | 0 | 59 | 6 / 8 | 1 | 1 |
| fixed | 1/50 | breeden_reachable | 147 | 73 | 0 | 54 | 6 / 8 | 1 | 1 |
| fixed | 1/50 | breeden_second_order | 147 | 127 | 0 | 0 | 6 / 8 | 1 | 1 |
| matched | 1/50 | continuous_cbf | 147 | 127 | 1 | 0 | 6 / 8 | 1 | 1 |
| matched | 1/50 | breeden | 147 | 105 | 0 | 22 | 4 / 8 | 3 | 1 |
| matched | 1/50 | breeden_reachable | 147 | 106 | 0 | 21 | 5 / 8 | 2 | 1 |
| matched | 1/50 | breeden_second_order | 147 | 127 | 0 | 0 | 6 / 8 | 1 | 1 |
| fixed | 1/10 | continuous_cbf | 147 | 80 | 0 | 26 | 6 / 8 | 1 | 1 |
| fixed | 1/10 | breeden | 147 | 34 | 0 | 72 | 3 / 8 | 4 | 1 |
| fixed | 1/10 | breeden_reachable | 147 | 50 | 0 | 56 | 6 / 8 | 1 | 1 |
| fixed | 1/10 | breeden_second_order | 147 | 101 | 0 | 5 | 6 / 8 | 1 | 1 |
| matched | 1/10 | continuous_cbf | 147 | 106 | 1 | 0 | 6 / 8 | 1 | 1 |
| matched | 1/10 | breeden | 147 | 26 | 0 | 80 | 2 / 8 | 5 | 1 |
| matched | 1/10 | breeden_reachable | 147 | 58 | 0 | 48 | 3 / 8 | 4 | 1 |
| matched | 1/10 | breeden_second_order | 147 | 101 | 0 | 5 | 6 / 8 | 1 | 1 |
| fixed | 1/5 | continuous_cbf | 147 | 80 | 0 | 8 | 6 / 8 | 1 | 1 |
| fixed | 1/5 | breeden | 147 | 21 | 0 | 67 | 1 / 8 | 6 | 1 |
| fixed | 1/5 | breeden_reachable | 147 | 33 | 0 | 55 | 3 / 8 | 4 | 1 |
| fixed | 1/5 | breeden_second_order | 147 | 77 | 0 | 11 | 6 / 8 | 1 | 1 |
| matched | 1/5 | continuous_cbf | 147 | 87 | 3 | 1 | 6 / 8 | 1 | 1 |
| matched | 1/5 | breeden | 147 | 21 | 0 | 67 | 1 / 8 | 6 | 1 |
| matched | 1/5 | breeden_reachable | 147 | 34 | 0 | 54 | 3 / 8 | 4 | 1 |
| matched | 1/5 | breeden_second_order | 147 | 77 | 0 | 11 | 6 / 8 | 1 | 1 |
| fixed | 2/5 | continuous_cbf | 147 | 76 | 4 | 2 | 6 / 8 | 1 | 1 |
| fixed | 2/5 | breeden | 147 | 17 | 0 | 61 | 1 / 8 | 6 | 1 |
| fixed | 2/5 | breeden_reachable | 147 | 21 | 0 | 57 | 1 / 8 | 6 | 1 |
| fixed | 2/5 | breeden_second_order | 147 | 50 | 0 | 28 | 6 / 8 | 1 | 1 |
| matched | 2/5 | continuous_cbf | 147 | 77 | 6 | 1 | 6 / 8 | 1 | 1 |
| matched | 2/5 | breeden | 147 | 10 | 0 | 68 | 1 / 8 | 6 | 1 |
| matched | 2/5 | breeden_reachable | 147 | 21 | 0 | 57 | 1 / 8 | 6 | 1 |
| matched | 2/5 | breeden_second_order | 147 | 50 | 0 | 28 | 6 / 8 | 1 | 1 |

All methods use the same b=d-tau*v initial set; continuous-CBF emulation has no held-path guarantee.
Fixed gain uses the configured k in Theorems 1–2. Matched gain uses k=gamma/T; Theorem 3 always uses gamma/T.
Unsafe b does not imply a geometric collision. Viability and barrier-domain labels are independent.
A zero-width admissible interval can be a feasible singleton. Infeasibility generates no fallback.
Finite control counts are not volumes; exact admissible interval widths are saved separately.
[Exact per-control evidence](study.json) · [Full rollout records](runs.json) · [Source and configuration](metadata.json)
