# tick-trap experiment

Counts describe these configurations only. A stopped run is not a safe completed horizon.

| Method | Initially viable* | Assumptions | Runs | Safe complete | Collision | Infeasible | Outside domain | Deadline misses |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| breeden | False | nominal model | 8 | 0 | 0 | 8 | 0 | 0 |
| breeden | True | nominal model | 56 | 19 | 0 | 29 | 8 | 1 |
| breeden_reachable | False | nominal model | 8 | 0 | 0 | 8 | 0 | 0 |
| breeden_reachable | True | nominal model | 56 | 28 | 0 | 20 | 8 | 0 |
| breeden_second_order | False | nominal model | 8 | 0 | 0 | 8 | 0 | 0 |
| breeden_second_order | True | nominal model | 56 | 48 | 0 | 0 | 8 | 0 |
| continuous_cbf | False | nominal model | 8 | 0 | 0 | 8 | 0 | 0 |
| continuous_cbf | True | nominal model | 56 | 48 | 0 | 0 | 8 | 0 |

*Viability uses the ideal no-delay wall formula with true braking authority.

Use a common configured horizon when comparing different update periods; fixed step counts imply different horizons.
A model match does not give endpoint-only or emulated continuous filters a hold guarantee.
Timing measurements are empirical; fixed simulated delay is configured independently.
The oracle is offline; its time is excluded from controller deadline measurements.

- [Full records](runs.json)
- [Per-run metrics](summary.csv)
- [Configuration and software provenance](metadata.json)
