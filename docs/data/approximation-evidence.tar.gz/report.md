# Approximate maps and observed safety contracts

Offline held-input map and property audit inspired by Taylor 2203.11470v2; no Taylor controller or practically invariant set family is implemented or certified

| Metric | Map | Holds | Nonzero map errors | Pointwise ingredients pass | Pass / exact next b outside | Pass / exact b samples inside, path outside |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| unit | euler | 32 | 24 | 11 | 1 | 0 |
| unit | midpoint | 32 | 0 | 11 | 0 | 4 |
| velocity_scaled | euler | 32 | 24 | 11 | 1 | 0 |
| velocity_scaled | midpoint | 32 | 0 | 11 | 0 | 4 |

| Metric | Radius | Holds | Samples within dilation | Path within dilation | Within dilation despite exact b violation |
| --- | --- | ---: | ---: | ---: | ---: |
| unit | 0 | 32 | 21 | 16 | 0 |
| unit | 1/100 | 32 | 25 | 21 | 5 |
| unit | 1/20 | 32 | 26 | 25 | 9 |
| unit | 1/10 | 32 | 27 | 27 | 11 |
| unit | 1/5 | 32 | 32 | 32 | 16 |
| velocity_scaled | 0 | 32 | 21 | 16 | 0 |
| velocity_scaled | 1/100 | 32 | 25 | 21 | 5 |
| velocity_scaled | 1/20 | 32 | 26 | 25 | 9 |
| velocity_scaled | 1/10 | 32 | 32 | 32 | 16 |
| velocity_scaled | 1/5 | 32 | 32 | 32 | 16 |

Distances use the declared normalized state coordinates and the halfspace C_b alone.
Observed dilation containment does not certify an invariant set family or imply geometric collision avoidance.
Exact geometric and barrier path statuses remain unchanged when a positive radius permits their violations.
Pointwise decrement ingredients do not establish all Taylor theorem hypotheses. No controller or fallback is synthesized.
[Complete exact evidence](audit.json) · [Source and configuration](metadata.json)
