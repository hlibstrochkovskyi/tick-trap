# Local zero-order constraint contracts

Local affine state-input proxy and numerical-condition audit of Tan 2411.17079v2; alternative bounds and diagnostic input pairings are not new controllers or full paper replications

| Buffer | Variant | Holds | Passes with safe left pair | Those passes / unsafe proxy | Valid local implication ingredients | Disagreements with exact history condition |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| norm_tube | exact_previous | 40 | 10 | 0 | 10 | 0 |
| norm_tube | euler_unadjusted | 40 | 10 | 0 | 10 | 0 |
| norm_tube | euler_tightened | 40 | 10 | 0 | 10 | 0 |
| norm_tube | midpoint_previous | 40 | 10 | 0 | 10 | 0 |
| norm_tube | reset_start_input | 40 | 10 | 0 | 13 | 3 |
| norm_tube | stale_end_input | 40 | 16 | 7 | 6 | 18 |
| projected_tube | exact_previous | 40 | 10 | 0 | 10 | 0 |
| projected_tube | euler_unadjusted | 40 | 11 | 0 | 10 | 1 |
| projected_tube | euler_tightened | 40 | 10 | 0 | 10 | 0 |
| projected_tube | midpoint_previous | 40 | 10 | 0 | 10 | 0 |
| projected_tube | reset_start_input | 40 | 12 | 0 | 15 | 3 |
| projected_tube | stale_end_input | 40 | 16 | 7 | 6 | 18 |
| candidate_derivative | exact_previous | 40 | 13 | 0 | 13 | 0 |
| candidate_derivative | euler_unadjusted | 40 | 13 | 0 | 12 | 0 |
| candidate_derivative | euler_tightened | 40 | 13 | 0 | 13 | 0 |
| candidate_derivative | midpoint_previous | 40 | 13 | 0 | 13 | 0 |
| candidate_derivative | reset_start_input | 40 | 15 | 0 | 19 | 2 |
| candidate_derivative | stale_end_input | 40 | 24 | 8 | 13 | 15 |
| oracle_absolute | exact_previous | 40 | 14 | 0 | 14 | 0 |
| oracle_absolute | euler_unadjusted | 40 | 14 | 1 | 12 | 2 |
| oracle_absolute | euler_tightened | 40 | 13 | 0 | 13 | 1 |
| oracle_absolute | midpoint_previous | 40 | 14 | 0 | 14 | 0 |
| oracle_absolute | reset_start_input | 40 | 16 | 0 | 20 | 2 |
| oracle_absolute | stale_end_input | 40 | 25 | 8 | 14 | 15 |
| oracle_backward_drop | exact_previous | 40 | 17 | 0 | 17 | 0 |
| oracle_backward_drop | euler_unadjusted | 40 | 17 | 3 | 13 | 6 |
| oracle_backward_drop | euler_tightened | 40 | 14 | 0 | 14 | 3 |
| oracle_backward_drop | midpoint_previous | 40 | 17 | 0 | 17 | 0 |
| oracle_backward_drop | reset_start_input | 40 | 20 | 0 | 24 | 3 |
| oracle_backward_drop | stale_end_input | 40 | 29 | 9 | 17 | 16 |
| endpoint_only | exact_previous | 40 | 20 | 3 | 11 | 0 |
| endpoint_only | euler_unadjusted | 40 | 18 | 4 | 9 | 8 |
| endpoint_only | euler_tightened | 40 | 15 | 1 | 10 | 5 |
| endpoint_only | midpoint_previous | 40 | 20 | 3 | 11 | 0 |
| endpoint_only | reset_start_input | 40 | 24 | 4 | 18 | 4 |
| endpoint_only | stale_end_input | 40 | 31 | 11 | 11 | 15 |

The proxy h=d-tau*v-sigma*u is not a physical rollover model and need not imply geometric clearance.
The endpoint uses the current held input, the left limit before the next update. Input jumps and previous-pair premises are recorded separately.
Only norm_tube uses the local norm-product recipe. Other buffers are explicitly derived offline references; zero buffers are not the paper's positive global constant.
Reset-start changes the paper's recurrence but may have a separate valid one-hold argument. A stale endpoint input may evaluate the wrong constraint.
Prediction-error tightening follows the published construction; no new controller or recursive-feasibility guarantee is asserted.
[Exact evidence](audit.json) · [Source and configuration](metadata.json)
